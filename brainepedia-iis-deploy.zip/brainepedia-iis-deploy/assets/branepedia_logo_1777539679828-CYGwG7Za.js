const o="/assets/branepedia_logo_1777539679828-CVybW96C.png";export{o as l};
