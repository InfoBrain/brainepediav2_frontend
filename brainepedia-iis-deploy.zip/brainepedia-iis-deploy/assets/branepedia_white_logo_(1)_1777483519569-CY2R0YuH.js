const o="/assets/branepedia_white_logo_(1)_1777483519569-CNsTtWx0.png";export{o as l};
